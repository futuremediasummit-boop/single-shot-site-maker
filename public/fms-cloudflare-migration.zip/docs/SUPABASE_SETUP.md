# Supabase setup

Everything the admin does lives in your Supabase project: logins, drafts, publishing, form submissions,
registrations and check-in. No GitHub edits and no redeploys are needed to change content.

## One-time setup (about 10 minutes)

1. **Run the SQL.** Supabase → SQL Editor → paste `docs/supabase-setup.sql` → Run.
   (If you already have the `fms_events`, `fms_ticket_types` and `fms_tickets` tables, skip "Part B".)
2. **Create your admin login.** Follow "PART C" at the bottom of that SQL file.
3. **Add the secrets** where the site runs (Cloudflare → your Worker → Settings → Variables and Secrets,
   type **Secret**), copied from Supabase → Project Settings → API:
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY` (the `service_role` key: never share it, never put it in the repo)
   - `SUPABASE_ANON_KEY` (the public `anon` key)
   - `CHECKIN_PIN` (any PIN you choose for door staff using `/verify`)
4. Open `/admin` on your live site and sign in.

Supabase's own "Site URL" setting does not matter: sign-in goes through the website's server, not Supabase's email links.

## How publishing works

- You type in the admin: it **auto-saves your draft to Supabase** (the "Saved" label at the top).
- **Publish** copies the draft to the live copy. The public site reads that copy, so changes appear within about 15 seconds.
- Only items switched to **Published** go into the live copy. Draft items never leave the admin.

## Who can do what

| | Editor | Admin |
|---|---|---|
| Write, edit, publish content and site settings | yes | yes |
| Check-in list, registrations | no | yes |
| Form inbox | no | yes |
| Add or remove team members, reset passwords | no | yes |

## Tickets and events (managed in Supabase for now)

The registration system reads `fms_events` and `fms_ticket_types`: price (`price_kes`), capacity, and whether
registration is open (`open`). Edit them in Supabase → Table Editor. **A `price_kes` of 0 means FREE and the ticket
is issued instantly**, so set real prices (or leave `open` = false) before you announce tickets.
