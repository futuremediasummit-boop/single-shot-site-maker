# Deploying on Cloudflare (from GitHub)

The build already targets Cloudflare Workers (it generates `.output/server/wrangler.json` and
`.wrangler/deploy/config.json`).

## One-time setup

1. Cloudflare dashboard → **Workers & Pages** → **Create** → **Import a repository** → pick this GitHub repo, branch `main`.
2. Build settings:
   - **Build command:** `bun run build`
   - **Deploy command:** `npx wrangler deploy`
   - If it asks for a Worker name and complains about a mismatch, use the name shown in the build log
     line "Using auto generated worker name".
3. **Build variables** (Settings → Build → Variables and secrets): `VITE_SITE_URL` = your public address
   (e.g. `https://futuremediasummit.com`). If the build can't find Bun, also add `BUN_VERSION` = `1`.
4. **Runtime secrets** (Settings → Variables and Secrets): `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`,
   `SUPABASE_ANON_KEY`, `CHECKIN_PIN` (see `docs/SUPABASE_SETUP.md`). Add them as type **Secret**.
5. **Custom domain:** Worker → Settings → Domains & Routes → Add. (A free `*.workers.dev` address works meanwhile.)

After that, every push to `main` deploys automatically. Use a branch + pull request for anything risky:
Cloudflare also builds branches as preview deployments.

## Checks after the first deploy

- Open the site: pages load and the admin sign-in appears at `/admin`.
- Sign in, edit something, press Publish, reload the public page.
- Submit the contact form and look for it in the admin Inbox.
- If a page shows "Supabase is not configured": the secrets in step 4 aren't reaching the Worker. Check the names exactly.

## Leaving Lovable (do this LAST, after the Cloudflare site works)

1. Lovable → Project settings → GitHub → disconnect.
2. Unpublish or delete the Lovable project so the old `lovable.app` address stops serving.
3. Optional: rotate your Supabase service-role key (Supabase → Project Settings → API) and update the Cloudflare secret,
   since the old key was also stored in Lovable.
