// OPTIONAL, UNTESTED: a Vite config with no Lovable package. Try it on a branch.
//   bun add -d @tailwindcss/vite
//   mv vite.config.ts vite.config.lovable.bak && mv vite.config.plain.ts vite.config.ts
//   bun remove @lovable.dev/vite-tanstack-config
//   NITRO_PRESET=cloudflare-module bun run build
// If the build fails, put the old file back (mv vite.config.lovable.bak vite.config.ts) and run `bun install`.
// When it works, set NITRO_PRESET=cloudflare-module as a Cloudflare BUILD variable too, and remove the
// "@lovable.dev" names from bunfig.toml.
import { defineConfig } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import tsConfigPaths from "vite-tsconfig-paths";
import { nitro } from "nitro/vite";

export default defineConfig(({ command }) => ({
  plugins: [
    tsConfigPaths(),
    tailwindcss(),
    tanstackStart({ server: { entry: "server" } }),
    viteReact(),
    ...(command === "build" ? [nitro()] : []),
  ],
}));
