# FMS Roadmap
- [x] Phase 1: brand system, logo, all public pages with honest "to be announced" states
- [x] Phase 2: Supabase — save contact/partner/accreditation/newsletter forms (needs go-ahead)
- [x] Phase 3: Admin dashboard + roles (Supabase) to manage summits, speakers, partners, news, stats
- [ ] Phase 4: Ticketing — M-Pesa (Daraja credentials) + card gateway, QR tickets, check-in
- [ ] Phase 5: Email (Resend/Gmail) and SMS (Africa's Talking credentials)
- [ ] Official content from organisation: dates, venue, contacts, leadership, logos
