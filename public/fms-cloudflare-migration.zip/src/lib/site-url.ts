/**
 * The public address of the website, used for share links and Google event data.
 * Set VITE_SITE_URL as a BUILD variable (Cloudflare → Settings → Build → Variables), e.g. https://futuremediasummit.com
 * With no variable set it falls back to the address below.
 */
export const SITE_URL = ((import.meta.env["VITE_SITE_URL"] as string | undefined) || "https://futuremediasummit.lovable.app").replace(/\/$/, "");
