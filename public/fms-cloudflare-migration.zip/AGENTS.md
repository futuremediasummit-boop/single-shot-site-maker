# Project notes

Future Media Summit website. Stack: TanStack Start (React), Tailwind, Supabase (database + logins), Cloudflare Workers (hosting), GitHub (code).

## Rules
- Live content is managed in the admin (`/admin`) and stored in Supabase. See `docs/SUPABASE_SETUP.md`.
- All Supabase access is server-side (`src/lib/supabase.server.ts`, `src/lib/admin-api.ts`). Never put the service-role key in browser code or in the repo; it lives in Cloudflare secrets.
- `src/content/site.ts` is only the starting content and brand text. Never invent organisational facts: empty lists must render a designed "coming soon" placeholder.
- Site chrome (Header/Footer) is mounted in `src/routes/__root.tsx`; section routes with children use a layout file returning `<Outlet />` plus an `index.tsx` leaf.
- Deploying: see `docs/DEPLOY_CLOUDFLARE.md`. Do not force-push `main`; it is what Cloudflare deploys.
