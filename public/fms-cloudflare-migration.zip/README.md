# Future Media Summit

Website and admin for the Future Media Summit.

- **Code:** GitHub (this repo)
- **Hosting:** Cloudflare Workers, deployed automatically from `main` (`docs/DEPLOY_CLOUDFLARE.md`)
- **Content, logins, forms, tickets:** Supabase (`docs/SUPABASE_SETUP.md`)

## Develop

```bash
bun install
bun run dev      # local site
bun run build    # production build
bun run test
```

Local secrets go in a `.dev.vars` file (never committed): `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `SUPABASE_ANON_KEY`, `CHECKIN_PIN`.
